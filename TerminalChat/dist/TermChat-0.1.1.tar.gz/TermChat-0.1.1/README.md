Simple terminal chat application.
